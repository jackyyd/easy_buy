<template>
  <h2 class="errtip">oops!你访问的页面不存在！</h2>
</template>

<script>
export default {
  name: 'NotFound',
  data () {
    return {
    }
  }
}
</script>

<style scoped>
.errtip{
 font-size:30px;
 margin:30px;
 font-weight:bold;
}
</style>
